# ISD-Dyah111-jurnal13
Dyah Ayuning Permata Sari
607062300134
47-04